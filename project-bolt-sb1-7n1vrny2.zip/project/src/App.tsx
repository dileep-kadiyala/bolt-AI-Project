import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { SkillsGrid } from './components/SkillsGrid';
import { AssessmentDashboard } from './components/AssessmentDashboard';
import { PortfolioSection } from './components/PortfolioSection';
import { StatsSection } from './components/StatsSection';
import { Footer } from './components/Footer';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Header onMenuToggle={() => setIsMenuOpen(!isMenuOpen)} isMenuOpen={isMenuOpen} />
      <main>
        <HeroSection />
        <SkillsGrid />
        <AssessmentDashboard />
        <StatsSection />
        <PortfolioSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;