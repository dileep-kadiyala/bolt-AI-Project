import React, { useState } from 'react';
import { Clock, CheckCircle, AlertCircle, Star, Play } from 'lucide-react';

export const AssessmentDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('available');

  const assessments = {
    available: [
      { id: 1, title: "React.js Fundamentals", duration: "45 min", difficulty: "Intermediate", rating: 4.8, participants: 1250 },
      { id: 2, title: "JavaScript ES6+ Features", duration: "30 min", difficulty: "Beginner", rating: 4.6, participants: 2100 },
      { id: 3, title: "System Design Basics", duration: "60 min", difficulty: "Advanced", rating: 4.9, participants: 890 },
      { id: 4, title: "Database Optimization", duration: "40 min", difficulty: "Intermediate", rating: 4.7, participants: 765 }
    ],
    completed: [
      { id: 5, title: "TypeScript Mastery", score: 95, date: "2024-01-15", badge: "Expert" },
      { id: 6, title: "Node.js Backend", score: 88, date: "2024-01-10", badge: "Proficient" },
      { id: 7, title: "CSS Grid & Flexbox", score: 92, date: "2024-01-05", badge: "Expert" }
    ]
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Assessment Dashboard</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Track your progress, take new assessments, and monitor your skill development journey.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              <button
                onClick={() => setActiveTab('available')}
                className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === 'available'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Available Assessments
              </button>
              <button
                onClick={() => setActiveTab('completed')}
                className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === 'completed'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Completed Assessments
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'available' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {assessments.available.map((assessment) => (
                  <div key={assessment.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">{assessment.title}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(assessment.difficulty)}`}>
                        {assessment.difficulty}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{assessment.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400" />
                        <span>{assessment.rating}</span>
                      </div>
                      <span>{assessment.participants} participants</span>
                    </div>

                    <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2">
                      <Play className="w-4 h-4" />
                      <span>Start Assessment</span>
                    </button>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'completed' && (
              <div className="space-y-4">
                {assessments.completed.map((assessment) => (
                  <div key={assessment.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <CheckCircle className="w-6 h-6 text-green-500" />
                      <div>
                        <h3 className="font-semibold text-gray-900">{assessment.title}</h3>
                        <p className="text-sm text-gray-600">Completed on {assessment.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className={`text-lg font-bold ${getScoreColor(assessment.score)}`}>
                          {assessment.score}%
                        </p>
                        <p className="text-sm text-gray-600">{assessment.badge}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};