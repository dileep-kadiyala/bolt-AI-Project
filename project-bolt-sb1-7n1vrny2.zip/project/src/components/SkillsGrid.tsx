import React from 'react';
import { Code, Database, Smartphone, Cloud, Shield, BarChart } from 'lucide-react';

export const SkillsGrid: React.FC = () => {
  const skills = [
    { icon: Code, name: "Frontend Development", level: 92, color: "bg-blue-500" },
    { icon: Database, name: "Backend Development", level: 88, color: "bg-green-500" },
    { icon: Smartphone, name: "Mobile Development", level: 78, color: "bg-purple-500" },
    { icon: Cloud, name: "Cloud Computing", level: 85, color: "bg-indigo-500" },
    { icon: Shield, name: "Cybersecurity", level: 82, color: "bg-red-500" },
    { icon: BarChart, name: "Data Analytics", level: 76, color: "bg-yellow-500" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Technical Proficiency</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Comprehensive skill assessment across multiple technology domains with real-time progress tracking.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-xl hover:shadow-lg transition-all duration-300 group">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 ${skill.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <skill.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{skill.name}</h3>
                    <p className="text-sm text-gray-600">{skill.level}% Proficiency</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Progress</span>
                  <span className="font-medium text-gray-900">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${skill.color} transition-all duration-1000 ease-out`}
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};